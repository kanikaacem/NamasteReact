import Button from '@mui/material/Button';
import {useSelector, useDispatch} from 'react-redux';
import Logout from './Logout';

const Header = () =>{
    const isLoggedIn = useSelector(state => state.isLoggedIn);   
    const dispatch = useDispatch();
    return (<>
    <nav>
        <div style={{width:'73px',height:'73px'}}>
            <a href="/">
                 <img src='./assets/companyLogo.png' alt="LOGO" width="100%"></img>
            </a>
        </div>
       
        <div className="AuthButtons">
        { isLoggedIn == 'true' ? 
        // <Button variant="contained" style={{textTransform:"capitalize",background:"#2B1E44"}}
        // onClick={() => dispatch({type:"LOGOUT"})}>Logout</Button> 
        <Logout ></Logout>
        : 
        <Button variant="contained" href="/login" style={{textTransform:"capitalize",background:"#2B1E44"}}>Login</Button>
        }
        {isLoggedIn != 'true' && <Button variant="outlined" style={{textTransform:"capitalize",color:"#2B1E44",border:"2px solid #2B1E44"}}>Sign up</Button> }
        </div>
    </nav>
    </>)
}

export default Header;