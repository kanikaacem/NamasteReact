const PartnerCompany = () =>{
    return (<>
        <div className="partnerCompany">
            <div style={{width:'180px',height:'60px'}}>
                <img src="./assets/paytm.png" alt="logo"></img>
            </div>
        </div>
    </>)
}
export default PartnerCompany;