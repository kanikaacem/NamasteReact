const AllCategories = () => {
    return (<>
     This is Category
    </>)
}

export default AllCategories;