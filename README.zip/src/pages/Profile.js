function Profile(){
    return (<>
    This is the Profile Page</>)
}
export default Profile;